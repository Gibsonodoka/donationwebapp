<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Friends of the Battalion')); ?></title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased bg-gray-100">
    <div class="min-h-screen">
        <?php if (isset($component)) { $__componentOriginal5358d2b526141fd28f26fcb6aca64978 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5358d2b526141fd28f26fcb6aca64978 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5358d2b526141fd28f26fcb6aca64978)): ?>
<?php $attributes = $__attributesOriginal5358d2b526141fd28f26fcb6aca64978; ?>
<?php unset($__attributesOriginal5358d2b526141fd28f26fcb6aca64978); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5358d2b526141fd28f26fcb6aca64978)): ?>
<?php $component = $__componentOriginal5358d2b526141fd28f26fcb6aca64978; ?>
<?php unset($__componentOriginal5358d2b526141fd28f26fcb6aca64978); ?>
<?php endif; ?>

        <?php if(isset($header)): ?>
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php if (isset($component)) { $__componentOriginalba56b9c686ea753b48a0ed0c415b53b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8)): ?>
<?php $attributes = $__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8; ?>
<?php unset($__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba56b9c686ea753b48a0ed0c415b53b8)): ?>
<?php $component = $__componentOriginalba56b9c686ea753b48a0ed0c415b53b8; ?>
<?php unset($__componentOriginalba56b9c686ea753b48a0ed0c415b53b8); ?>
<?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH /Users/ameka/Documents/UWHETU/Laravel/wos/resources/views/layouts/app.blade.php ENDPATH**/ ?>