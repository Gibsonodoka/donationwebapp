<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Confirm Password - Friends of the Battalion</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-blue-100 text-gray-800">

  <!-- NAVBAR COMPONENT -->
  <?php if (isset($component)) { $__componentOriginal5358d2b526141fd28f26fcb6aca64978 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5358d2b526141fd28f26fcb6aca64978 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5358d2b526141fd28f26fcb6aca64978)): ?>
<?php $attributes = $__attributesOriginal5358d2b526141fd28f26fcb6aca64978; ?>
<?php unset($__attributesOriginal5358d2b526141fd28f26fcb6aca64978); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5358d2b526141fd28f26fcb6aca64978)): ?>
<?php $component = $__componentOriginal5358d2b526141fd28f26fcb6aca64978; ?>
<?php unset($__componentOriginal5358d2b526141fd28f26fcb6aca64978); ?>
<?php endif; ?>

  <!-- CONFIRM PASSWORD SECTION -->
  <main class="flex-grow flex items-center justify-center py-16 px-4">
    <div class="w-full max-w-md bg-white/90 backdrop-blur-md rounded-2xl shadow-xl p-8">

      <!-- Header -->
      <div class="text-center mb-6">
        <h1 class="text-2xl font-semibold text-gray-800">Confirm Your Password</h1>
        <p class="text-gray-600 mt-2 text-sm">
          This is a secure area of the application. Please confirm your password before continuing.
        </p>
      </div>

      <!-- Display session status (if any) -->
      <?php if(session('status')): ?>
        <div class="mb-4 p-3 text-sm text-green-700 bg-green-100 border border-green-300 rounded-lg">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <!-- Confirm Password Form -->
      <form method="POST" action="<?php echo e(route('password.confirm')); ?>" class="space-y-5">
        <?php echo csrf_field(); ?>

        <div>
          <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
          <input id="password" name="password" type="password" required autocomplete="current-password"
                 class="w-full rounded-lg border border-gray-300 px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex items-center justify-end">
          <button type="submit"
                  class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition">
            Confirm
          </button>
        </div>
      </form>
    </div>
  </main>

  <!-- FOOTER COMPONENT -->
  <?php if (isset($component)) { $__componentOriginalba56b9c686ea753b48a0ed0c415b53b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8)): ?>
<?php $attributes = $__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8; ?>
<?php unset($__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba56b9c686ea753b48a0ed0c415b53b8)): ?>
<?php $component = $__componentOriginalba56b9c686ea753b48a0ed0c415b53b8; ?>
<?php unset($__componentOriginalba56b9c686ea753b48a0ed0c415b53b8); ?>
<?php endif; ?>

</body>
</html>
<?php /**PATH /Users/ameka/Documents/UWHETU/Laravel/wos/resources/views/auth/confirm-password.blade.php ENDPATH**/ ?>