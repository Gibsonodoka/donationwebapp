

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-semibold text-gray-800 mb-6">Donation Management</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-50 border border-green-300 text-green-700 rounded-lg p-4 mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="overflow-x-auto bg-white rounded-lg shadow-sm border">
        <table class="w-full text-sm text-left text-gray-700">
            <thead class="bg-gray-100 text-gray-600 uppercase text-xs">
                <tr>
                    <th class="px-6 py-3">User</th>
                    <th class="px-6 py-3">Support Area</th>
                    <th class="px-6 py-3">Amount</th>
                    <th class="px-6 py-3">Crypto</th>
                    <th class="px-6 py-3">Status</th>
                    <th class="px-6 py-3">Receipt</th>
                    <th class="px-6 py-3 text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-4"><?php echo e($donation->user->name); ?></td>
                        <td class="px-6 py-4"><?php echo e($donation->support_area); ?></td>
                        <td class="px-6 py-4"><?php echo e($donation->amount); ?></td>
                        <td class="px-6 py-4"><?php echo e($donation->crypto_type); ?></td>
                        <td class="px-6 py-4 capitalize">
                            <?php if($donation->status === 'confirmed'): ?>
                                <span class="text-green-600 font-semibold">Confirmed</span>
                            <?php elseif($donation->status === 'rejected'): ?>
                                <span class="text-red-600 font-semibold">Rejected</span>
                            <?php else: ?>
                                <span class="text-yellow-600 font-semibold">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <?php if($donation->receipt_path): ?>
                                <a href="<?php echo e(asset('storage/'.$donation->receipt_path)); ?>" target="_blank"
                                   class="text-blue-600 hover:underline">View</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <?php if($donation->status === 'pending'): ?>
                                <div class="flex justify-center gap-2">
                                    <form action="<?php echo e(route('admin.donations.confirm', $donation->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 text-xs">
                                            Confirm
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('admin.donations.reject', $donation->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 text-xs">
                                            Reject
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <span class="text-gray-400 text-sm italic">No Action</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ameka/Documents/UWHETU/Laravel/wos/resources/views/Admin/donations.blade.php ENDPATH**/ ?>