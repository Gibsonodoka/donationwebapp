<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Verify Email - Friends of the Battalion</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-blue-100 text-gray-800">

  <!-- NAVBAR COMPONENT -->
  <?php if (isset($component)) { $__componentOriginal5358d2b526141fd28f26fcb6aca64978 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5358d2b526141fd28f26fcb6aca64978 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5358d2b526141fd28f26fcb6aca64978)): ?>
<?php $attributes = $__attributesOriginal5358d2b526141fd28f26fcb6aca64978; ?>
<?php unset($__attributesOriginal5358d2b526141fd28f26fcb6aca64978); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5358d2b526141fd28f26fcb6aca64978)): ?>
<?php $component = $__componentOriginal5358d2b526141fd28f26fcb6aca64978; ?>
<?php unset($__componentOriginal5358d2b526141fd28f26fcb6aca64978); ?>
<?php endif; ?>

  <!-- VERIFY EMAIL SECTION -->
  <main class="flex-grow flex items-center justify-center py-16 px-4">
    <div class="w-full max-w-md bg-white/90 backdrop-blur-md rounded-2xl shadow-xl p-8">

      <!-- Header -->
      <div class="text-center mb-6">
        <h1 class="text-2xl font-semibold text-gray-800">Verify Your Email</h1>
        <p class="text-gray-600 mt-2 text-sm">
          Thanks for signing up! Before getting started, please verify your email address by clicking on the link we just sent you.
          If you didn’t receive the email, we’ll gladly send you another.
        </p>
      </div>

      <!-- Status message -->
      <?php if(session('status') == 'verification-link-sent'): ?>
        <div class="mb-4 font-medium text-sm text-green-700 bg-green-100 border border-green-300 rounded-lg p-3">
          A new verification link has been sent to the email address you provided during registration.
        </div>
      <?php endif; ?>

      <!-- Buttons -->
      <div class="mt-6 flex items-center justify-between">
        <!-- Resend Verification -->
        <form method="POST" action="<?php echo e(route('verification.send')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit"
            class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition">
            Resend Verification Email
          </button>
        </form>

        <!-- Logout -->
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit"
            class="text-sm text-gray-700 hover:text-red-600 font-medium underline transition">
            Log Out
          </button>
        </form>
      </div>
    </div>
  </main>

  <!-- FOOTER COMPONENT -->
  <?php if (isset($component)) { $__componentOriginalba56b9c686ea753b48a0ed0c415b53b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8)): ?>
<?php $attributes = $__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8; ?>
<?php unset($__attributesOriginalba56b9c686ea753b48a0ed0c415b53b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba56b9c686ea753b48a0ed0c415b53b8)): ?>
<?php $component = $__componentOriginalba56b9c686ea753b48a0ed0c415b53b8; ?>
<?php unset($__componentOriginalba56b9c686ea753b48a0ed0c415b53b8); ?>
<?php endif; ?>

</body>
</html>
<?php /**PATH /Users/ameka/Documents/UWHETU/Laravel/wos/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>